#Ziyi Zhang
#2/8/2022

def print_list(C):
    ''' take in contacts and change the contacts'''
    print("================== CONTACT LIST ==================\n")
    print("Index   First Name            Last Name\n")
    print("======  ====================  ====================\n")
    for i in range(len(C)):
        print(f'{str(i):8}{C[i][0]:22}{C[i][1]:22}')

def add_contact(C):
    '''taking contact and modify data '''
    first=input("Please enter your firstname:")
    second=input("please enter your lastnaem:")
    C.append([first,second])
    return C

def modify_contact(C):
    '''take in the index to add and add more info'''
    index=int(input("Please enter your number:"))
    if len(C) > index:
        userfisrt = input("please enter your firestname:")
        userlast = input("please enter your lastname:")
        C[index]=[userfisrt, userlast]
        return C
    else:
        print("Invalid index number.")
        return C

def delete_contact(C):
    '''take in the index compare in range if so delete'''
    index=int(input("Please enter your number:"))
    if len(C) > index:
        C.pop(index)
        return C
    else:
        print("Invalid index number.")
        return C
