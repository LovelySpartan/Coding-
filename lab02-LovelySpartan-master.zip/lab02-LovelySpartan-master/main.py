from contacts import*
C=[]

while True:
    print("*** TUFFY TITAN CONTACT MAIN MENU")
    print("1. Print list\n")
    print("2. Add contact\n")
    print("3. Modify contact\n")
    print("4. Delete contact\n")
    print("5. Exit the program\n")
    choice= int(input("Enter menu choice:"))
    if choice == 1 :
        print_list(C)
    elif choice == 2 :
        C=add_contact(C)
    elif choice == 3 :
        C=modify_contact(C)
    elif choice == 4 :
        C=delete_contact(C)
    elif choice == 5 :
        break
