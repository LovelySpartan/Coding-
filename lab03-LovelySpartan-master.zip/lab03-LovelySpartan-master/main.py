from contacts import*
C=[]
a = True

while True:
    print("*** TUFFY TITAN CONTACT MAIN MENU")
    print("1. Print list\n")
    print("2. Add contact\n")
    print("3. Modify contact\n")
    print("4. Delete contact\n")
    print("5. Exit the program\n")
    print("6.sort list by first name\n")
    print("7.sort list by last name\n")
    choice= int(input("Enter menu choice:"))
    if choice == 1 :
        print_list(C)
    elif choice == 2 :
        first_name = input("Please enter your first name:")
        last_name = input("Please enter last name:")
    elif choice == 3 :
        index=int(input("Please enter your number:"))
        userfisrt = input("please enter your firestname:")
        userlast = input("please enter your lastname:")
        a = modify_contact(C, first_name = userfisrt, last_name = userlast, index = index )
    elif choice == 4 :
        index=int(input("Please enter your numbe"))
        a = delete_contact(C, index=index)
    elif choice == 5 :
        sort_contacts(c, column = 0)
    elif choice == 6:
         sort_contacts(c , column = 1)
    elif choice == 7 :
         break
