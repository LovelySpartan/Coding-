#!/bin/bash
python3 -m unittest -v test
python3 -m test
