def print_list(C):
    ''' take in contacts and change the contacts'''
    print("================== CONTACT LIST ==================\n")
    print("Index   First Name            Last Name\n")
    print("======  ====================  ====================\n")
    for i in range(len(C)):
        print(f'{str(i):8}{C[i][0]:22}{C[i][1]:22}')

def add_contact(C, /, *, first_name,last_name):
    '''taking contact and modify data '''
    C.append([first_name,last_name])

def modify_contact(C, /, * ,  first_name , last_name , index ):
    '''take in the index to add and add more info'''
    if len(C) > index:
        C[index]=[first_name, last_name]
        return True
    else:
        print("Invalid index number.")
        return False

def delete_contact(C, /, *, index):
    '''take in the index compare in range if so delete'''
    if len(C) > index:
        C.pop(index)
        return True
    else:
        print("Invalid index number.")
        return False

def sort_contacts(C, /, *, column):
    if column == 0:
        C.sort(key = lambda x:x[0])
    elif column ==1:
        C.sort(key = lambda x:x[1])
