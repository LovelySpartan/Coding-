def print_list(C):
    ''' take in contacts and change the contacts'''
    print("================== CONTACT LIST ==================\n")
    print(" Last Name             First Name            Phone\n")
    print("======  ====================  ====================\n")
    keys = tuple(C.keys())
    vals = list(C.values())
    for i in range(len(vals)):
        print(f'{vals[i][1]:22}{vals[i][0]:7}{keys[i]:22}')
def add_contact(C, /, *, id, first_name,last_name):
    '''taking contact and modify data '''
    if id in C.keys():
        return "error"
    else:
        C[id]=[first_name,last_name]
        return C.get(id)
def modify_contact(C, /, * , id , first_name , last_name ):
    '''take in the index to add and add more info'''
    if id in C.keys():
        C[id] = [first_name , last_name]
        return C.get(id)
    else:
        return "error"

def delete_contact(C, /, *, id):
    '''take in the index compare in range if so delete'''
    if id in C.keys():
        deli = C.pop(id)
        return deli
    else:
        return "error"

def sort_contacts( C ) :
    sort = sorted(C.items(), key =
            lambda kv:(kv[0], kv[1]))
    sorted_dict = {k: v for k, v in sort}
    return sorted_dict
def find_contact(C, /, * , find):
    C=sort_contacts(C)
    emp = {}
    if find.isnumeric():
        find = int(find)
        find_key = C.get(find)

        emp[find] = find_key
    else:
        find = find[0].upper() + find[1:]
        for id, names in C.items():
            for key in names:
                if find in names:
                    emp[id] = names
    return emp
