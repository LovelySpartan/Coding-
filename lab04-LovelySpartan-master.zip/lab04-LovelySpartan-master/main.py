#Ziyi Zhang
#2/17/2022
#calling function from header file and pass value
from contacts import*
C={}
a = True

while True:
    print("*** TUFFY TITAN CONTACT MAIN MENU")
    print("1. Add contact\n")
    print("2. Modify contact\n")
    print("3. Delete contact\n")
    print("4. Print list\n")
    print("5.Find contact\n")
    print("6. Exit the program\n")
    choice= int(input("Enter menu choice:"))
    if choice == 1 :
        id = input("Please enter your phone number:")
        first_name = input("Please enter your first name")
        last_name = input("Please enter your last name")
        if id.isnumeric():
            id = int(id)
            result = add_contact( C ,id = id , first_name = first_name ,
            last_name = last_name)
            if result == "error":
                print("number already exsit")
            else:
                print('added:', result)
        else:
            print("invaild input")
    elif choice == 2 :
        id = (input("Please enter your number:"))
        first_name = input("please enter your firestname:")
        last_name= input("please enter your lastname:")
        if id.isnumeric():
            id = int(id)
            a = modify_contact(C, first_name = first_name, last_name = last_name,
             id = id )
            if a == "error":
                print(a)
            else:
                print("phone number doesn't exist")
        else:
            print("invaild input")
    elif choice == 3 :
        id = (input("Please enter your number:"))
        if id.isnumeric():
            id = int(id)
            deli = delete_contact(id)
            if deli == "error":
               print("phone number does not exist")
            else:
                ptint ("deleted:", deli)
    elif choice == 4 :
        print_list(C)
        
    elif choice == 5 :
        sort_contacts(C)
    elif choice == 6:
        N = input("n")
        find_contact(C , find = N)
    elif choice == 7 :
         break
